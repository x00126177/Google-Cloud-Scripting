#!/bin/bash

# isolation 
echo "this is the number of processes running from Docker: " 
ps aux | wc -l
end 


echo "This is the no. of processes running on VM: " 
ps aux | wc -l

# Virtualized H/W resources
