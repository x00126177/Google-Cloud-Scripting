#!/bin/bash

echo "This is the no. of processes" & ps -ef | wc -l 
