#!/bin/bash

echo "Hello from Docker"
