#!/bin/bash

# script to create and backup and tar file
#var1=$1
#var2=$2
#var3=$3


if [ -z "$1" ] || [ -z "$2" ] || [ -z "$3" ]
then
	echo "invalid parameters, try again"
	exit 1
else
	tar -cvf $2.tar $1
	gsutil cp $2.tar gs://$3
fi

