# X00126177 James Carroll
# IT Management

The module aims are to develop the skills required to evaluate
typical enterprise software architectures in order to make
strategic recommendations in support of both application
architecture and infrastructure management. Following from
this, to develop the ability to recommend key disaster recovery
and fail-over plans and processes, and to suggest methods by
which production software systems may be made both stable
and highly-available.
