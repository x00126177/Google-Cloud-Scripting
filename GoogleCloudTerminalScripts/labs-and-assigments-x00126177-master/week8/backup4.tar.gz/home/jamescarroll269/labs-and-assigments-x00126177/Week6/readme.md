Week 6

- Show isolation of the Dockerfile, do this by showing the processes running on Docker vs the console

- Show that containers do not virtualize H/W resources e.g. CPU
