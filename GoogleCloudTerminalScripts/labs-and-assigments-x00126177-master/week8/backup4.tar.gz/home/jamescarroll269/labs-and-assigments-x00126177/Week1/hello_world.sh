#!/bin/bash

#coment
echo "Hello everyone"
echo "this is a line"

